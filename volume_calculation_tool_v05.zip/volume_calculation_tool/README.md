# Volume Calculation Tool For QGIS

The volume calculation tool is a plugin for QGIS which allows for easy calculation of volumes defined by polygons and DEM layers.

## Installation

- Use the internal QGIS plugin manager.
- Download the repository and move it into the appropriate QGIS plugin folder.
- In order to build/use the documentation use the makefile with the command `make doc` which should build the documentation html into a build folder inside the help folder.
- In order to create a deployable zip simply use `make zip`

## Usage

See the documentation in the help folder.
and/or the tutorial video in the example folder

## Build With

[Qgis-Plugin Builder](https://github.com/g-sherman/Qgis-Plugin-Builder/)

## License
Copyright (C) 2020-2026 REDcatch GmbH.
[GPL](https://www.gnu.org/licenses/gpl-3.0.en.html)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
